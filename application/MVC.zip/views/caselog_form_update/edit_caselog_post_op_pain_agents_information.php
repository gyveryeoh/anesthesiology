<?php foreach ($patient_information as $data): endforeach; ?>
<div align="center">		   
<form method="post" id="anesth_form"  action="<?php echo base_url(); ?>index.php/edit_caselog_controller/edit_post_op_agents_information">
<input type="hidden" name="patient_information_id" value="<?php echo $data->patient_information_id?>"/>
<input type="hidden" name="patient_form_id" value="<?php echo $data->patient_form_id; ?>"/>
<input type="hidden" name="anesth_status_id" value="<?php echo $data->anesth_status_id; ?>"/>
<table border="0" cellpadding="0" width="90%" cellspacing="2" style="font-family: sans-serif; border: solid 1px; font-size: 14px;">
 <tr>
                    <td class="border-less" bgcolor="skyblue" colspan="4">POST OP AGENT</td>
          </tr>
          <tr>
            <td class="border-less" colspan="2"><input type="checkbox" style="display: none;" name='post_op_pain_agent[]' class='post_op_pain_agent_required'></td>
          <?php
          $num_cols = 3;
          $current_col = 0;
          $x = 0;
          foreach($anesth_agent_data as $aad):
          if($current_col == "0")echo "<tr>";
          
		  echo "<td bgcolor='FAFAD2'><input type='checkbox' value='".$aad->id."' id='post_op_agent' name='post_op_pain_agent[]'";
		  
		  foreach($patient_form_post_op_pain_agent_details as $pfpopad)
		  {
			if($pfpopad->id == $aad->id)
			{
				echo "checked";
				break;
			}
		  }
		  
		  
		  echo ">".$aad->name."</td>";
		  
		  if($current_col == $num_cols-1)
          {
            echo "</tr>";
            $current_col = 0;
            }
            else
            {
                $current_col++;
            }
            $x++;
            endforeach;
	   ?>
	    <?php
	     //Other Main Agents
	   if($data->other_post_op_pain_agent == "NULL")
	   {
		   $display ='style=display:none;';
	   }
	   else
	   {
		   $display='style=display:block;';
	   }
	   ?>
	    <tr>
            <td bgcolor='FAFAD2'><input type="checkbox" name="other_post_op_pain_agent" id="81" value="other_post_op_agent_checkbox" <?php if($data->other_post_op_pain_agent != "NULL"){echo "checked=checked";}?>>Others Please Specify : </td>
            <td class="border-less"  id="other_post_op_pain_agent" <?php echo $display; ?>><input type="text" size="20" name="other_post_op_pain_agent_data" class="other_post_op_pain_agent_valid" value="<?php if($data->other_post_op_pain_agent == "NULL") echo ""; else { echo $data->other_post_op_pain_agent; }?>"></td>
          </tr>
	    <tr><td class="border-less"><BR></td></tr>
	   <tr>
	    <td class="border-less"><input type="submit" name="submit" value="Save Information"></td>
	   </tr>
	   <tr>
<td colspan="3" align="center" class="border-less"><br><br><br>Copyright 2013 PGH - Philippine General Hospital </td>
</tr>
</table>
</form>	
<script type="text/javascript" src="<?php echo base_url(); ?>assets/javascript/datepicker/zebra_datepicker.js"></script>
<script>
$('input[id="81"]').change(function(){
    var pClass = '.'+$(this).val();
    if ($(this).is(':checked')){
        
      $('#other_post_op_pain_agent').show('slow');
      $('.other_post_op_pain_agent_valid').attr('class','other_post_op_pain_agent_required');
      $('.post_op_pain_agent_required').attr('class','post_op_pain_agent_valid');
    }
    else{
      $('#other_post_op_pain_agent').hide();
      $('.other_post_op_pain_agent_required').attr('class','other_post_op_pain_agent_valid');
      $('.post_op_pain_agent_valid').attr('class','post_op_pain_agent_required');
    }
});
$('input[id="post_op_pain_agent"]').prop(function(){
    var pClass = '.'+$(this).val();
    if ($(this).is(':unchecked'))
    {
      $('.post_op_pain_agent_required').attr('class','post_op_pain_agent_valid');
    }
});
</script>