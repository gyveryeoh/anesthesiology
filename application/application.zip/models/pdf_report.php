<?php
Class Pdf_report extends CI_Model
{
 function select_patient_information($patients_id)
 {
     $this->db->select('*,patient_form.id as patient_form_id,
                       patient_information.lastname as patient_information_lastname,
                       patient_information.firstname as patient_information_firstname,
                       patient_information.middle_initials as patient_information_middle_initials,
                       anesth_services.name as service_name,
                       anesth_technique.name as technique_name,
                       anesth_blood_loss.name as blood_loss_name');
     $this->db->from('patient_information');
     $this->db->join('users', 'users.id = patient_information.user_id');
     //Patient Form
     $this->db->join('patient_form', 'patient_information.id = patient_form.patient_information_id');
     //Services
     $this->db->join('anesth_services', 'anesth_services.id = patient_form.service');
     //Techniques
     $this->db->join('anesth_technique', 'anesth_technique.id = patient_form.anesthetic_technique');
     //Blood Loss
     $this->db->join('anesth_blood_loss', 'anesth_blood_loss.id = patient_form.blood_loss');
     $this->db->where('patient_information.id', $patients_id);
     $query = $this->db->get();
     if($query->num_rows() > 0)
            {
              return $query->result();
            } else {
                    return false;
            }
}
function patient_form_main_agent_details($patient_form_id)
{
 $this->db->select('*');
 $this->db->from('patient_form_main_agent_details');
 $this->db->join('anesth_agent', 'anesth_agent.id = patient_form_main_agent_details.anesth_agent_id ');        
 $this->db->where('patient_form_id',$patient_form_id);
  $query = $this->db->get();
   return $query->result();
}
function patient_form_supplementary_agent_details($patient_form_id)
{
 $this->db->select('*');
 $this->db->from('patient_form_supplementary_agent_details');
 $this->db->join('anesth_agent', 'anesth_agent.id = patient_form_supplementary_agent_details.anesth_agent_id ');        
 $this->db->where('patient_form_id',$patient_form_id);
  $query = $this->db->get();
   return $query->result();
}
function patient_form_post_op_pain_agent_details($patient_form_id)
{
 $this->db->select('*');
 $this->db->from('patient_form_post_op_pain_agent_details');
 $this->db->join('anesth_agent', 'anesth_agent.id = patient_form_post_op_pain_agent_details.anesth_agent_id ');        
 $this->db->where('patient_form_id',$patient_form_id);
  $query = $this->db->get();
   return $query->result();
}
function patient_form_monitors_used_details($patient_form_id)
{
 $this->db->select('*');
 $this->db->from('patient_form_monitors_used_details');
 $this->db->join('anesth_monitors', 'anesth_monitors.id = patient_form_monitors_used_details.monitors_used_id');        
 $this->db->where('patient_form_id',$patient_form_id);
  $query = $this->db->get();
   return $query->result();
}
function patient_form_apgar_details($patient_form_id)
{
 $this->db->select('*');
 $this->db->from('patient_form_apgar_details');
 $this->db->where('patient_form_id',$patient_form_id);
  $query = $this->db->get();
   return $query->result();
}
}
?>