<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
          <meta charset="UTF-8">
          <title>ANESTHESIOLOGY</title>
<noscript>
          <meta http-equiv="refresh" content="0; url=http://oltrap.pchrd.dost.gov.ph/index.php/administrator/javascript/" />
</noscript>
          <link href="<?php echo base_url(); ?>assets/css/style.css" media="screen" rel="stylesheet" type="text/css">
          <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/datepicker/style.css">
          <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/datepicker/default.css">
          <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/datepicker/style_date.css">
          <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/datepicker/shCoreDefault.css">
          
          <script type="text/javascript" src="<?php echo base_url(); ?>assets/javascript/datepicker/XRegExp.js"></script>
          <script type="text/javascript" src="<?php echo base_url(); ?>assets/javascript/datepicker/shCore.js"></script>
          <script type="text/javascript" src="<?php echo base_url(); ?>assets/javascript/datepicker/shLegacy.js"></script>
          <script type="text/javascript" src="<?php echo base_url(); ?>assets/javascript/datepicker/shBrushJScript.js"></script>
          <script type="text/javascript">
            //Datepicker
	    SyntaxHighlighter.defaults['toolbar'] = false;
            SyntaxHighlighter.all();     
        </script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/javascript/jquery.js"></script>
        <script>
	//Datepicker Format
	$(document).ready(function(){
	$('#datepicker-example11').Zebra_DatePicker({
        format: 'Y-m-d'
	});
	$('#datepicker-example14').Zebra_DatePicker({
        format: 'Y-m-d'
	});
	$('#datepicker-example13').Zebra_DatePicker({
        format: 'Y-m-d'
	});
	$('#datepicker-example12').Zebra_DatePicker({
        view: 'years'
	});
        });
        </script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/javascript/jquery.validate.min.js"></script>
</head>
<table border="1" width=80%" cellpadding="0" cellspacing="0" class="table">
          <tr align="center">
                    <td class="header td_left" width="80%">ANESTHESIOLOGY INFORMATION SYSTEM</td>
                    <td class="td_right"><img src="<?php echo base_url();?>assets/images/pgh_logo.jpg" width="50%" height="10%"></td>
          </tr>
          <tr>
                    <td class="border-less" style="background-color:#FFF5EE; font-family: sans-serif;font-size: 16px;font-weight:bold;">&nbsp; You are logged in as : <?php echo ucwords($lastname).", ".ucwords($firstname)." ".ucwords($middle_initials)."."; ?></td>
                    <td align="right" class="border-less" style="background-color:#FFF5EE; font-family: sans-serif;font-size: 10px;font-weight:bold;"><a href="<?php echo base_url();?>index.php/home">Home</a> |
                    <?php
                    if ($role_id == "2")
                    {
                              echo '<a href="'.base_url().'index.php/home/resident_lists">Submitted Form</a> |';
                    }
                    ?>
                    <a href="<?php echo base_url();?>index.php/home/logout">Logout</a> 
                    </td>
          </tr>
</table>