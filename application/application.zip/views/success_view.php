<table border="1" width="80%" cellpadding="10" cellspacing="0" style="font-size: 20px;">
          <tr>
                    <td colspan="2" class="border-less" align="center"><b>SUCCESSFULLY CREATED CASE LOG FORM</b></td>
          </tr>
	  <tr><td class="border-less"></td></tr>
	   <tr>
                    <td colspan="2" class="border-less" align="center"><b>BACK TO THE <b style="color: RED;"><a href="<?php echo base_url();?>index.php/home">HOME PAGE</a></b></td>
          </tr>
	   <tr>
                    <td colspan="2" class="border-less" align="center"><b></b></td>
          </tr>
         
</table>
